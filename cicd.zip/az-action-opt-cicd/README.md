# az-action-opt-cicd

- This repo aims to host the reusable workflows that provide a standardised CI/CD approach for opt applications.

## CI/CD Set-up

- Guidance for setting up a new CI/CD pipeline (with required K8s secrets) can be found in [opt-docs](https://github.com/AZ-AI/opt-docs).
- This CI/CD repo requires the use of three environments: dev, preprod and prod. An optional test deployment pipeline for a separate test environment is also present.
- To add the these workflows to your repo copy a `.github/workflows/` directory from one of the supported Optimiser platform applications (e.g. from [opt-sweops-qc](https://github.com/AZ-AI/opt-sweops-qc)) into the new project repository. Example workflow files are also kept in the `workflow-caller-files/` folder but these are not necessarily kept up to date.

## CI/CD Pipelines Overview

Detailed instructions on the CI/CD pipelines can be found in the [opt-docs](https://github.com/AZ-AI/opt-docs) repo. Below briefly outlines each of the main CI/CD pipelines and the reusable workflows that used.

1. [Frontend Release Pipeline](#frontend-release-pipeline-frontend-releaseyml)
2. [Code Checks](#code-checks-code-checksyml)
3. [Optimiser Release Pipeline](#optimiser-release-pipeline-opt-releaseyml)
4. [Streamlit Release Pipeline](#streamlit-release-pipeline-streamlit-releaseyml)

### Frontend Release Pipeline (frontend-release.yml)

The Frontend Release Pipeline is used to deploy frontend applications to Kubernetes, with 4 possible environments: test, dev, pre-prod and prod.
It uses the below reusable workflows:

1. [Check Git Tag](#check-git-tag-matches-semver-value-check-git-tagyml)
2. [Frontend Code Checks](#frontend-code-checks-frontend-code-checksyml)
3. [Build Images](#build-images-image-build-pushyml)
4. [Apply K8s Resources](#apply-k8s-resources-apply-k8s-resourcesyml)
5. [Check Lower Environment](#check-lower-environment-version-check-lower-envyml)
6. [Create Github Release](#create-github-release-create-gh-releaseyml)

### Code Checks (code-checks.yml)

This workflow uses the below reusable workflows, to allow a full code check of a repo:

1. [Frontend Code Checks](#frontend-code-checks-frontend-code-checksyml)
2. [Optimiser Code Checks](#optimiser-code-checks-opt-code-checksyml)

### Optimiser Release Pipeline (opt-release.yml)

The Optimiser release pipeline is used to build the optimiser image, push the to harbor, and create a GH release.
It uses the below reusable workflows

1. [Optimiser Code Checks](#optimiser-code-checks-opt-code-checksyml)
<!-- TODO: Update Optimiser Release Pipeline to use Image-Build-Push and GH Release Pipeline, after refactoring those workflows to work with optimiser images. -->

### Streamlit Release Pipeline (streamlit-release.yml)

The Streamlit release pipeline is used to build the optimiser/streamlit image, push the to harbor, and deploy to Kubernetes
It uses the below reusable workflows

1. [Optimiser Code Checks](#optimiser-code-checks-opt-code-checksyml)
<!-- TODO: Update Streamlit Release Pipeline to use Image-Build-Push and apply-k8s-resources, after refactoring those workflows to work with optimiser images. -->

## Reusable Workflows

This section details each of the Reusable workflows, which essentially act as modules in the larger pipelines above.

1. [Apply K8S Resources](#apply-k8s-resources-apply-k8s-resourcesyml)
2. [Check Git Tag Matches Semver Value](#check-git-tag-matches-semver-value-check-git-tagyml)
3. [Check Lower Environment Version](#check-lower-environment-version-check-lower-envyml)
4. [Check Package/Package-lock.json Versions](#check-packagepackage-lockjson-versions-check-semvers-matchyml)
5. [Create Github Release](#create-github-release-create-gh-releaseyml)
6. [Frontend Code Checks](#frontend-code-checks-frontend-code-checksyml)
7. [Build Images](#build-images-image-build-pushyml)
8. [Optimiser Code Checks](#optimiser-code-checks-opt-code-checksyml)

### Apply K8S Resources (apply-k8s-resources.yml)

This workflow is used to apply latest frontend resources to a Kubernetes namespace. It uses a SemVer artifact created by a previous job to extract the frontend image version, with a frontend Kubernetes deployment manifest template to create an updated Kubernetes manifest which is then applied to the desired environment. This restarts the Kubernetes frontend deployment, using the latest docker image from Harbor.

### Check Git Tag Matches Semver Value (check-git-tag.yml)

This workflow is used to extract the package.json version and check it matches the git tag used in the frontend deployment pipeline.

### Check Lower Environment Version (check-lower-env.yml)

This workflow is used as part of the frontend deployment CI/CD pipeline, to check the git tag version being deployed is the same as the version used in the lower environment (e.g. comparing prod is the same as pre-prod). It takes the lower environment version from the Harbor Image used in Kubernetes.

### Check Package/Package-lock.json Versions (check-semvers-match.yml)

This workflow extracts the frontend package.json version and both package-lock.json versions and check they match.

### Create Github Release (create-gh-release.yml)

This workflow is used in the frontend deployment CI/CD pipeline to create GH releases based on the git tag used. When deploying to pre-production, the workflow will take the GH release template contained in the repo's .github/release.yml, and produce a draft GH release with templated release notes. When deploying to production the workflow will "publish" the previously made GH release draft.

### Frontend Code Checks (frontend-code-checks.yml)

This workflow used to run the following frontend code checks:

1. Check ESLinting.
2. Check Prettier Formatting.
3. Run Unit Tests.
4. Check Package/Package-lock.json versions match via check-semvers-match.yml.

### Build Images (image-build-push.yml)

This workflow is used to build Docker images on AZ's self-hosted runners and push them to Harbor container registry. The image is built using the docker file in the repos's opt or frontend directories.

### Optimiser Code Checks (opt-code-checks.yml)

This workflow used to run the following optimiser code checks:

1. Set-up GH runner with Python version from pyproject.toml file along with dependencies.
2. Check black formatting.
3. Run Pytest unit tests.
